import { WatchlistRow } from '../types/watchlist';

const KEY = 'cts:watchlist:manual-import:v1';

export function saveWatchlist(rows: WatchlistRow[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(rows));
  } catch (e) {
    console.error('saveWatchlist failed', e);
    throw e;
  }
}

export function loadWatchlist(): WatchlistRow[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as WatchlistRow[];
    return parsed;
  } catch (e) {
    console.error('loadWatchlist failed', e);
    return [];
  }
}

export function clearWatchlist() {
  try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
}
