// src/components/ManualImport.tsx
import { useEffect, useMemo, useRef, useState } from 'react';

export type WatchlistRow = {
  symbol: string;
  date: string; // DD-MM-YYYY
  category: 'GENERAL' | 'OPTIONS' | 'FUTURES' | string;
  // internal flags
  validated?: boolean;
  error?: string | null;
};

export const STORAGE_KEY = 'cts:watchlist:manual-import:v1';

export interface ManualImportProps {
  isOpen?: boolean;
  onClose?: () => void;
  onImport?: (rows: WatchlistRow[]) => Promise<void> | void;
}

const defaultRow = (): WatchlistRow => ({
  symbol: '',
  date: new Date().toLocaleDateString('en-GB').replace(/\//g, '-'), // DD-MM-YYYY
  category: 'GENERAL',
  validated: false,
  error: null,
});

function validateSymbol(sym: string) {
  if (!sym) return 'Required';
  // uppercase letters and numbers only, no spaces
  if (!/^[A-Z0-9]+$/.test(sym)) return 'Invalid symbol';
  return null;
}
function validateDate(d: string) {
  // expect DD-MM-YYYY
  if (!/^\d{2}-\d{2}-\d{4}$/.test(d)) return 'Invalid date';
  const [dd, mm, yyyy] = d.split('-').map(Number);
  const dt = new Date(yyyy, mm - 1, dd);
  if (dt.getFullYear() !== yyyy || dt.getMonth() !== mm - 1 || dt.getDate() !== dd) return 'Invalid date';
  return null;
}

function saveToLocal(rows: WatchlistRow[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
  } catch (e) {
    // ignore localStorage errors in strict environments
    // console.warn('localStorage save failed', e);
  }
}

function loadFromLocal(): WatchlistRow[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as WatchlistRow[];
    return parsed;
  } catch {
    return [];
  }
}

export default function ManualImport(props: ManualImportProps) {
  const { isOpen = false, onClose, onImport } = props;
  const [rows, setRows] = useState<WatchlistRow[]>(() => [defaultRow(), defaultRow()]);
  const firstInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    // focus first input when modal opens
    if (isOpen) {
      setTimeout(() => firstInputRef.current?.focus(), 40);
    }
  }, [isOpen]);

  useEffect(() => {
    // If LocalStorage had saved rows, load them into the dialog when opened.
    if (isOpen) {
      const saved = loadFromLocal();
      if (saved && saved.length) {
        setRows(saved.map(r => ({ ...r, validated: false, error: null })));
      }
    }
  }, [isOpen]);

  const allValid = useMemo(() => {
    for (const r of rows) {
      const sErr = validateSymbol((r.symbol || '').toUpperCase().trim());
      const dErr = validateDate(r.date || '');
      if (sErr || dErr) return false;
    }
    return rows.length > 0;
  }, [rows]);

  const setRow = (idx: number, patch: Partial<WatchlistRow>) => {
    setRows(prev => {
      const copy = prev.slice();
      copy[idx] = { ...copy[idx], ...patch };
      // auto-validate on change
      const sym = (copy[idx].symbol || '').toUpperCase().trim();
      copy[idx].symbol = sym;
      const sErr = validateSymbol(sym);
      const dErr = validateDate(copy[idx].date || '');
      copy[idx].error = sErr ?? dErr ?? null;
      copy[idx].validated = !copy[idx].error;
      return copy;
    });
  };

  const addRow = (r?: Partial<WatchlistRow>) => {
    setRows(prev => [...prev, { ...defaultRow(), ...(r ?? {}) }]);
  };
  const deleteRow = (idx: number) => {
    setRows(prev => prev.filter((_, i) => i !== idx));
  };

  const handleImport = async () => {
    // validate all rows
    const checked = rows.map(r => {
      const symbol = (r.symbol || '').toUpperCase().trim();
      const sErr = validateSymbol(symbol);
      const dErr = validateDate(r.date || '');
      return {
        ...r,
        symbol,
        validated: !(sErr || dErr),
        error: sErr ?? dErr ?? null,
      };
    });
    setRows(checked);
    const invalid = checked.find(r => !r.validated);
    if (invalid) {
      // focus first invalid row's symbol input (best-effort)
      const idx = checked.findIndex(r => !r.validated);
      const el = document.querySelectorAll<HTMLInputElement>('[data-manual-symbol]')[idx];
      el?.focus();
      return;
    }

    try {
      if (onImport) {
        await Promise.resolve(onImport(checked));
        // If onImport succeeded, do not duplicate localStorage (follow original requirement)
      } else {
        // fallback: save to localStorage
        saveToLocal(checked);
      }
    } catch (e) {
      // fallback to localStorage if onImport rejects
      saveToLocal(checked);
      // optionally notify user; don't throw
      console.warn('onImport rejected — saved locally', e);
    } finally {
      // Dispatch event so other parts of app can react
      try {
        window.dispatchEvent(new CustomEvent('cts:watchlist:imported', { detail: checked }));
      } catch (_) {}
      // Close modal if parent provided onClose
      onClose?.();
    }
  };

  const handlePaste = (text: string) => {
    // Accept lines: SYMBOL[,|<TAB>]DD-MM-YYYY[,|<TAB>]CATEGORY
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const parsed: WatchlistRow[] = [];
    for (const line of lines) {
      const parts = line.split(/\t|,/).map(p => p.trim());
      const sym = (parts[0] || '').toUpperCase();
      const date = parts[1] || (new Date().toLocaleDateString('en-GB').replace(/\//g, '-'));
      const category = (parts[2] || 'GENERAL').toUpperCase();
      parsed.push({
        symbol: sym,
        date,
        category,
        validated: false,
        error: null,
      });
    }
    if (parsed.length) {
      setRows(prev => [...prev, ...parsed]);
    }
  };

  const handleFileUpload = async (file: File | null) => {
    if (!file) return;
    const txt = await file.text();
    handlePaste(txt);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
      <div
        className="absolute inset-0 bg-black/60"
        onClick={() => onClose?.()}
        aria-hidden="true"
      />
      <div className="relative w-full max-w-2xl bg-slate-900 rounded-lg border border-slate-700 shadow-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-slate-100 font-semibold">Manual Import Watchlist</h3>
          <button
            aria-label="Close"
            onClick={() => onClose?.()}
            className="px-2 py-1 rounded hover:bg-slate-800"
          >
            ✕
          </button>
        </div>

        <div className="space-y-3">
          <div className="flex gap-3 items-center">
            <div className="flex-1">
              <input
                type="file"
                accept=".csv,.txt"
                onChange={(e) => handleFileUpload(e.target.files?.[0] ?? null)}
                className="block w-full text-sm text-slate-400"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                // read clipboard (if allowed)
                navigator.clipboard?.readText().then(t => handlePaste(t)).catch(() => {});
              }}
              className="px-3 py-1 rounded bg-slate-800 text-slate-200"
            >
              Paste
            </button>
            <button
              type="button"
              onClick={() => addRow()}
              className="px-3 py-1 rounded bg-slate-800 text-slate-200"
            >
              + Add Row
            </button>
          </div>

          <div className="max-h-64 overflow-auto border border-slate-700 rounded p-2 bg-slate-800/40">
            <table className="w-full table-fixed text-sm">
              <thead>
                <tr className="text-slate-300 text-left">
                  <th className="w-1/12">#</th>
                  <th className="w-4/12">Symbol</th>
                  <th className="w-3/12">Date</th>
                  <th className="w-3/12">Category</th>
                  <th className="w-1/12">Del</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, idx) => (
                  <tr key={idx} className="border-b border-slate-700">
                    <td className="py-2">{idx + 1}</td>
                    <td className="py-2">
                      <input
                        data-manual-symbol
                        ref={idx === 0 ? firstInputRef : undefined}
                        value={r.symbol}
                        onChange={(e) => setRow(idx, { symbol: e.target.value.toUpperCase() })}
                        placeholder="Stock Symbol"
                        className="w-full bg-transparent border border-slate-700 rounded px-2 py-1 text-slate-100"
                      />
                      {r.error && <div className="text-xs text-amber-300 mt-1">{r.error}</div>}
                    </td>
                    <td className="py-2">
                      <input
                        value={r.date}
                        onChange={(e) => setRow(idx, { date: e.target.value })}
                        placeholder="DD-MM-YYYY"
                        className="w-full bg-transparent border border-slate-700 rounded px-2 py-1 text-slate-100"
                      />
                    </td>
                    <td className="py-2">
                      <select
                        value={r.category}
                        onChange={(e) => setRow(idx, { category: e.target.value })}
                        className="w-full bg-transparent border border-slate-700 rounded px-2 py-1 text-slate-100"
                      >
                        <option value="GENERAL">GENERAL</option>
                        <option value="OPTIONS">OPTIONS</option>
                        <option value="FUTURES">FUTURES</option>
                      </select>
                    </td>
                    <td className="py-2 text-center">
                      <button
                        onClick={() => deleteRow(idx)}
                        className="px-2 py-1 rounded bg-rose-700 text-white"
                        aria-label={`Delete row ${idx + 1}`}
                      >
                        🗑
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end gap-3 mt-3">
            <button
              onClick={() => { onClose?.(); }}
              className="px-4 py-2 rounded bg-slate-700 text-slate-200"
            >
              Cancel
            </button>
            <button
              onClick={handleImport}
              disabled={!allValid}
              className={`px-4 py-2 rounded text-white ${allValid ? 'bg-emerald-600' : 'bg-emerald-600/40 cursor-not-allowed'}`}
            >
              Import Stocks
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}


//this is a testing line




