@echo off
setlocal
cd /d D:\chenna-trading-system-dashboard\chenna-CTS\backend

REM set port if not set
if "%BACKEND_PORT%"=="" set BACKEND_PORT=3001

echo Starting backend on 0.0.0.0:%BACKEND_PORT% ...
node server.cjs
echo Backend exited with code %errorlevel%
pause
