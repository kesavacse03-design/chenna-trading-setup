// Minimal CTS backend (health-only)
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.BACKEND_PORT ? Number(process.env.BACKEND_PORT) : 3001;
const startedAt = new Date().toISOString();
const version = '0.1.0-min';

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', version, startedAt, now: new Date().toISOString() });
});

app.get('/version', (req, res) => {
  res.json({ version, startedAt });
});

app.use((req, res) => res.status(404).json({ error: 'Not Found' }));

app.listen(PORT, () => {
  console.log(`[CTS] backend listening on http://localhost:${PORT}`);
});
